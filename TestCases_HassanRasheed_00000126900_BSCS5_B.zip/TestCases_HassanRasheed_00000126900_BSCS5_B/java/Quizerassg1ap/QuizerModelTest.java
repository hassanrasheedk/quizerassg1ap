/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Quizerassg1ap;

import java.util.concurrent.TimeoutException;
import junit.framework.TestCase;

/**
 *
 * @author hassa
 */
public class QuizerModelTest extends TestCase {
    

    /**
     * Test of savePreviousRecords method, of class QuizerModel.
     */
    public void testSavePreviousRecordswithTimeOut()throws InterruptedException, TimeoutException {
        Thread testThread=new Thread(){
            public void run(){
        System.out.println("savePreviousRecords");
        QuizerModel.savePreviousRecords();
            }
        };
        testThread.start();
        Thread.sleep(1000);
        testThread.interrupt();

    if (testThread.isInterrupted()) {
        throw new TimeoutException("the test took too long to complete");
    }
    }

    
}
