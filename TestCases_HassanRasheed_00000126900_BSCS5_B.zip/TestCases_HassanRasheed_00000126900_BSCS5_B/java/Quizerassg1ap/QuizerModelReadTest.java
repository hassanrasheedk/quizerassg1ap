/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Quizerassg1ap;

import java.util.List;
import java.util.concurrent.TimeoutException;
import junit.framework.TestCase;

/**
 *
 * @author hassa
 */
public class QuizerModelReadTest extends TestCase {
    
//    public QuizerModelReadTest(String testName) {
//        super(testName);
//    }

    /**
     * Test of openFile method, of class QuizerModelRead.
     */
    public void testOpenFileWithTimeOut() throws InterruptedException, TimeoutException {
        Thread testThread=new Thread(){
            public void run(){
        System.out.println("openFile");
        QuizerModelRead.openFile();
            }
        };
        testThread.start();
        Thread.sleep(1000);
        testThread.interrupt();

    if (testThread.isInterrupted()) {
        throw new TimeoutException("the test took too long to complete");
    }
    }

    /**
     * Test of readRecords method, of class QuizerModelRead.
     */
    public void testReadRecordsWithTimeOut()throws InterruptedException, TimeoutException{
        Thread testThread=new Thread(){
            public void run(){
        System.out.println("readRecords");
        List result = QuizerModelRead.readRecords();
            }
        };
        testThread.start();
        Thread.sleep(1000);
        testThread.interrupt();

        if (testThread.isInterrupted()) {
            throw new TimeoutException("the test took too long to complete");
        }
    }

    /**
     * Test of readRecord method, of class QuizerModelRead.
     */
    public void testReadRecordWithTimeOut()throws InterruptedException, TimeoutException {
        Thread testThread=new Thread(){
            public void run(){
        System.out.println("readRecord");
        String title ="";
        Quiz result = QuizerModelRead.readRecord(title);
            }
        };
        testThread.start();
        Thread.sleep(1000);
        testThread.interrupt();

        if (testThread.isInterrupted()) {
            throw new TimeoutException("the test took too long to complete");
        }
    }

    /**
     * Test of closeFile method, of class QuizerModelRead.
     */
    public void testCloseFileWithTimeOut()throws InterruptedException, TimeoutException {
        Thread testThread=new Thread(){
            public void run(){
        System.out.println("closeFile");
        QuizerModelRead.closeFile();
            }
        };
        testThread.start();
        Thread.sleep(1000);
        testThread.interrupt();

        if (testThread.isInterrupted()) {
            throw new TimeoutException("the test took too long to complete");
        }
    }
    
}
