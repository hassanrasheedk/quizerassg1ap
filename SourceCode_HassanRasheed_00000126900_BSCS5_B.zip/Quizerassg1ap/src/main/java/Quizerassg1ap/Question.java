/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Quizerassg1ap;

import java.io.Serializable;

/**
 *
 * @author hassa
 */

public class Question implements Serializable {
    String type;
    String text;
    String expectedans;
    String[] mcqarray=new String[4];
    
    public Question(){}
    
    Question(String type, String text, String expectedans, String option1, String option2, String option3, String option4){
        this.type=type;
        this.text=text;
        this.expectedans=expectedans;
        mcqarray[0]=option1;
        mcqarray[1]=option2;
        mcqarray[2]=option3;
        mcqarray[3]=option4;
    }
    Question(String type, String text, String expectedans){
        this.type=type;
        this.text=text;
        this.expectedans=expectedans;
        mcqarray=null;
    }
}
