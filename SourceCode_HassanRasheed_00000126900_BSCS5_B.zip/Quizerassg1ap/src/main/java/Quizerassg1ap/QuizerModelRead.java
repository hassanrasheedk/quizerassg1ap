/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Quizerassg1ap;

import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author hassa
 */
public class QuizerModelRead {
    private static ObjectInputStream inputa;
    
    public static void openFile(){
        try // open file
        {
            System.out.printf("Inside try of openFile in QuizerModelRead");
            inputa = new ObjectInputStream(Files.newInputStream(Paths.get("quiz.ser")));
        }    
        catch (IOException ioException)
        {
           System.err.println("Error opening file.");
           System.exit(1); 
        }
    }
    
    public static List readRecords(){
        List<Quiz> qlist=new ArrayList();
        openFile();
        try
        {
            while (true) // loop until there is an EOFException
            {   
                qlist.add((Quiz) inputa.readObject());
            }
        }
        catch (EOFException endOfFileException)
        {
            System.out.printf("No more records%n");
        }
        catch (ClassNotFoundException classNotFoundException)
        {
            System.err.println("Invalid object type. Terminating.");
        }
        catch (IOException ioException)
        {
            System.err.println("Error reading from file. Terminating.");
        }
        closeFile();
        return qlist;
    }
    
    public static Quiz readRecord(String title){
        openFile();
        try
        {
            while (true) // loop until there is an EOFException
            {   
                Quiz record = (Quiz) inputa.readObject();
                String tt=record.getTitle();
                if(tt.equals(title)){
                    return record;
                }
            }
        }
        catch (EOFException endOfFileException)
        {
            System.out.printf("No more records%n");
        }
        catch (ClassNotFoundException classNotFoundException)
        {
            System.err.println("Invalid object type. Terminating.");
        }
        catch (IOException ioException)
        {
            System.err.println("Error reading from file. Terminating.");
        }
        closeFile();
        return new Quiz();
    } // end method readRecords
    
    public static void closeFile()
    {
        try
        {
            if (inputa != null)
            inputa.close();
        }
        catch (IOException ioException)
        {
            System.err.println("Error closing file. Terminating.");
            System.exit(1);
        }
    }
}
