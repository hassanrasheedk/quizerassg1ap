/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Quizerassg1ap;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author hassa
 */
public class Quiz implements Serializable {
    String title;
    String description;
    int questionnumber;
    int totalmarks;
    List<Question> questions=new ArrayList();
    Quiz(String title, String description){
        this.title=title;
        this.description=description;
        questionnumber=0;
    }
    Quiz(String title, String description, List<Question> qlist, int totalmarks)
    {
    this.title=title;
    this.description=description;
    questions=qlist;
    questionnumber=0;
    }
    
    Quiz(){}
    
    public String getTitle(){
        return title;
    }
    
    public String getDescription(){
        return description;
    }
    
    public int getNumOfQuestions(){
        return questionnumber;
    }
    
    public void addQuestionMCQ(String type, String text, String expectedans, String option1, String option2, String option3, String option4){
    questions.add(new Question(type, text, expectedans, option1, option2, option3, option4));
    questionnumber++;
    }
    public void addQuestionTrueFalse(String type, String text, String expectedans){
    questions.add(new Question(type, text, expectedans));
    questionnumber++;
    }
    public void addQuestionNumeric(String type, String text, String expectedans){
    questions.add(new Question(type, text, expectedans));
    questionnumber++;
    }
}
