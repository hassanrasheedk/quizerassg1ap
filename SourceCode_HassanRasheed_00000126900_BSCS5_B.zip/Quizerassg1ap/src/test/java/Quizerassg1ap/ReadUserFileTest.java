/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Quizerassg1ap;

import java.util.List;
import junit.framework.TestCase;

/**
 *
 * @author hassa
 */
public class ReadUserFileTest extends TestCase {
   

    public void testReadRecord() {
        System.out.println("readRecord");
        String userName = "hassanr";
        String password = "papa";
        String userName1 = "hassan";
        String password1 = "pokemon";
        User result = ReadUserFile.readRecord(userName, password);
        User result2 = ReadUserFile.readRecord(userName1, password1);
        assertFalse(result.equals(result2));
    }
    
}
