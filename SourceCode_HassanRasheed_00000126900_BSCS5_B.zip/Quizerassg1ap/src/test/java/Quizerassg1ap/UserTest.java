/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Quizerassg1ap;

import junit.framework.TestCase;

/**
 *
 * @author hassa
 */
public class UserTest extends TestCase {
    
public void testUsersEquality(){
    User student=new User("Hassan","Rasheed","Student");
    User instructor=new User("Hassan","Rasheed","Instructor");
    User student1=new User("Hassan","Rasheed","Instructor");
    User instructor1=new User("Hassan","Rasheed","Student");
    User student2=new User("Hassan","Rasheed","Student");
    User student3=new User("Hassan","Rasheed","Student",0);
    assertFalse(student.equals(instructor));
    assertFalse(student1.equals(instructor1));
    assertFalse(student2.equals(student3));
}
    
}
